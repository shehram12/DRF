from home.views import index,person,login,PersonsAPI,PeopleViewSet,RegisterAPI

from django.urls import path
from django.urls import path, include
from rest_framework.routers import DefaultRouter



router = DefaultRouter()
router.register(r'people', PeopleViewSet, basename='People')

urlpatterns=router.urls





urlpatterns = [
       path('',include(router.urls)),
       path('register/',RegisterAPI.as_view()),
     path('index/',index), 
     path('person/',person),
     path('login/',login),
     path('personapi/',PersonsAPI.as_view())
    
]