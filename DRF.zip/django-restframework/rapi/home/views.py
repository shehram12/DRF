from rest_framework.decorators import api_view
from rest_framework.response import Response
from turtle import color
from home.models import Person
from home.serializers import PeopleSerializer,LoginSerializer,RegisterSerializer

from rest_framework.decorators import APIView
from rest_framework import viewsets
from rest_framework import status
from django.contrib.auth.models import User
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import render
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.decorators import action




def person(request):
    # Your logic here
    return render(request, 'person.html')


class LoginAPI(APIView):
    def post(self,request):
        data=request.data
        serializer =LoginSerializer(data=data)
        if not serializer.is_vaild():
            return Response({
                'status':False,
                'message':serializer.errors
            },status.HTTP_400_BAD_REQUEST )


class RegisterAPI(APIView):
    def post(self,request):
        data=request.data
        serializer=RegisterSerializer(data=data)

      
        if not serializer.is_vaild():
            return Response({
                'status':False,
                'message':serializer.errors
            },status.HTTP_400_BAD_REQUEST )
        serializer.save()
        return Response({'status':True,'message':'user craeted'},status.HTTP_201_CREATED)

        user=authenticate(username=serializer.data['username'],
                      password=serializer.data['password'])
        print(user)

        if not user:
            return Response({
                'status':False,
                'message':'invalid credentials'
            },status.HTTP_400_BAD_REQUEST)
        
        token,_= Token.objects.get_or_create(user=user)
        print(token)
        return Response({
            'status':True,
            'message':'user login','token':str(token)},status.HTTP_201_CREATED
        )
        print(serializer.data)

@api_view(['GET','POST','PUT','PATCH'])
def index(request):

    if request.method == 'GET':  
     json_response = {
        'name':'Scalar',
        'courses':['C++','Python'],
        'method':'GET'
    }
     
    else :
        data = request.data
        print(data)
        json_response ={
          'name':'Scalar',
          'courses':['C++','Python'],
           'method':'POST'
        }
    
        return Response(json_response)

@api_view(['POST'])
def login(request):
   data=request
   serializer= LoginSerializer(data=data)
   
   if serializer.is_valid():
      data=serializer.data
      print(data)
   return Response({'message':'success'})     
   return Response(serializer.error)

from django.core.paginator import Paginator


class PersonsAPI(APIView):
   permission_classes=[IsAuthenticated]
   authentication_classes=[TokenAuthentication]
   def get(self,request):
        
        try:
            print(request.user)
            objs= Person.objects.filter(color__isnull=False)
            page=request.GET.get('page',1)
            page_size=3
            paginator=Paginator(objs,page_size)
            serializer=PeopleSerializer(paginator.page(page),many=True)
            
            paginator=Paginator(objs,page_size)
            
            serializer = PeopleSerializer(paginator.page(page),many=True)
            
            return Response(serializer.data)
        
        except Exception as e:
            return Response({'status':False,'message':'invalid page number'})
        
        

   def post(self,request):
         data= request.data
         serializer = PeopleSerializer(data=data)
         if serializer.is_vaild():
              serializer.save()
              return Response(serializer.data)


              return Response(serializer.errors)
      
   def put(self,request):
     data = request.data           
     serializer =PeopleSerializer(data=data)
     if serializer.is_vaild():
               serializer.save()
               return Response(serializer.data)
               return Response(serializer.errors)

   def patch(self,request):
       data = request.data  
       obj= Person.objects.get(id=data['id'])         
       serializer =PeopleSerializer(obj,data=data,partial =True)
       if serializer.is_vaild():
               serializer.save()
               return Response(serializer.data)
               return Response(serializer.errors)
      
   def delete(self,request):
       data= request.data 
       obj= Person.objects.get(id=data['id'])
       obj.delete()
       return Response({'message':'person deleted'})          
           

   

@api_view(['GET','POST','PUT','PATCH','DELETE'])
def people(request):
        if request.GET:
            objs= Person.objects.filter(color__isnull=False)
            serializer = PeopleSerializer(objs,many=True)
            return Response(serializer.data)
        elif request.method =='POST':
           data= request.data
           serializer = PeopleSerializer(data=data)
           if serializer.is_vaild():
              serializer.save()

              return Response(serializer.errors)
           
           elif request.method =='PUT':
              data = request.data           
              serializer =PeopleSerializer(data=data)
              if serializer.is_vaild():
               serializer.save()
              return Response(serializer.errors)
           
           elif request.method =='PATCH':
              data = request.data  
              obj= Person.objects.get(id=data['id'])         
              serializer =PeopleSerializer(obj,data=data,partial =True)
              if serializer.is_vaild():
               serializer.save()
              return Response(serializer.errors)
           
           else:
              data= request.data 
              obj= Person.objects.get(id=data['id'])
              obj.delete()
              return Response({'message':'person deleted'})          
           



class PeopleViewSet(viewsets.ModelViewSet):
    serializer_class=PeopleSerializer
    queryset=Person.objects.all()
    http_method_names=['get','post','put','patch','delete']


def list(self,request):
    search=request.GET.get('search')
    queryset=Person.objects.all()
    if search:
        queryset=queryset.filter(name__startswith=search)
      
    serialaizer=PeopleSerializer(queryset,many=True)
    return Response({'status': 200 , 'data':serialaizer.data }, status=status.HTTP_204_NO_CONTENT)


@action(detail=False, methods=['post'])
def send_mail_to_person(self,request,pk):
   print(pk)
   obj=Person.objects.get(pk=pk)
   serializer= PeopleSerializer(obj)
   return Response({
       'status':True,
       'messagae':'mail sent ',
       'data':serializer.data
   })