from django.contrib import admin

from home.models import Color,Person
# Register your models here.
admin.site.register(Color)
admin.site.register(Person)